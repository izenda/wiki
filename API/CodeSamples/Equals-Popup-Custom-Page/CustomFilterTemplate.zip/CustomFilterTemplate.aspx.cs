﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Izenda.AdHoc;

public partial class ProductName : Page
{
    private void WriteCustomControlsValues(string fullColumnName, string[] oldValues)
    {
        //In this method custom controls must be created and filled with old values
        string[] nodes = fullColumnName.Replace("[", "").Replace("]", "").Split('.');
        string tableName = nodes[nodes.Length - 2];
        if (nodes.Length >= 3)
            tableName = nodes[nodes.Length - 3] + "." + tableName;
        string columnName = nodes[nodes.Length - 1];
        DataTable table = AdHocContext.Driver.GetDataTable(string.Format("SELECT DISTINCT {0} FROM {1} ORDER BY {0} ASC", columnName, tableName));
        int ddlCount = 0;
        int cbCount = 0;
        CountControls(ref ddlCount, divFilters.Controls, ref cbCount);
        string labelColumn = columnName.EndsWith("y") && ddlCount > 1 ? columnName.Substring(0, columnName.Length - 1) + "ies" : ddlCount > 1 ? columnName + "s" : columnName;
        lblSelectedFilters.Text = string.Format("Select {0} {1}", ddlCount, labelColumn);
        selectedProduct1.Items.Add("...");
        selectedProduct2.Items.Add("...");
        foreach (DataRow row in table.Rows)
        {

            selectedProduct1.Items.Add((row[0]).ToString());
            selectedProduct2.Items.Add((row[0]).ToString());
        }
        if (oldValues.Length >= 2)
        {
            selectedProduct1.SelectedValue = oldValues[0];
            selectedProduct2.SelectedValue = oldValues[1];
        }
    }

    private void ReadCustomControlsValues(ref List<string> selected)
    {
        //In this method list of new values must be returned
        selected.Add(selectedProduct1.SelectedItem.Text);
        selected.Add(selectedProduct2.SelectedItem.Text);
    }

    #region SupportingCode
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsCallback && !Page.IsPostBack)
        {
            valueFieldId.Value = Request.Params["valueeditid"];
            columnFieldId.Value = Request.Params["columneditid"];
            loadedField.Value = "0";
            submittedField.Value = "0";
        }
    }

    public void Submit(object sender, EventArgs e)
    {
        List<string> selectedNodes = new List<string>();
        ReadCustomControlsValues(ref selectedNodes);
        string sel = "";
        for (int index = 0; index < selectedNodes.Count; index++)
        {
            sel += selectedNodes[index];
            if (index < selectedNodes.Count - 1)
                sel += ",";
        }
        valueField.Value = sel;
        submittedField.Value = "1";
    }

    public void Prepare(object sender, EventArgs e)
    {
        loadedField.Value = "1";
        string[] oldValues;
        if (!String.IsNullOrEmpty(valueField.Value))
            oldValues = valueField.Value.Split(',');
        else
            oldValues = new string[0];
        WriteCustomControlsValues(columnField.Value, oldValues);
    }

    private static void CountControls(ref int ddlCount, ControlCollection controls, ref int cbCount)
    {
        foreach (Control wc in controls)
        {
            if (wc is DropDownList)
                ddlCount++;
            else if (wc is CheckBox)
                cbCount++;
            else if (wc.Controls.Count > 0)
                CountControls(ref ddlCount, wc.Controls, ref cbCount);
        }
    }
    #endregion
}
