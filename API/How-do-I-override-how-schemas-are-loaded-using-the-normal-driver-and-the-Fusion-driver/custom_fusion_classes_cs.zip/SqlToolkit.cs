﻿using System;
using System.Data;
using Izenda;
using Izenda.AdHoc;
using Izenda.AdHoc.Database;

public static class SqlToolkit {
	public static IDbCommand CreateCommand(Driver driver, string command)
	{
		return CreateCommand(driver, null, command, null, null);
	}

	public static IDbCommand CreateCommand(Driver driver, string command, SqlParam[] parameters)
	{
		return CreateCommand(driver, null, command, null, parameters);
	}

	public static IDbCommand CreateCommand(Driver driver, IDbConnection connection, string command, CommandType? commandType, SqlParam[] parameters)
	{
		IDbCommand comm = driver.CreateCommand(command);
		comm.CommandTimeout = driver.CmdTimeout;
		if (connection != null)
			comm.Connection = connection;
		if (commandType != null)
			comm.CommandType = commandType.Value;
		if (parameters == null)
			return comm;
		foreach (var param in parameters)
		{
			if (!param.IgnoreEmpty)
			{
				comm.Parameters.Add(driver.CreateParameter(param.Name, param.Value));
				continue;
			}
			if (param.Value == null)
				continue;
			var type = param.Value.GetType();
			if (Equals(param.Value, type.IsValueType ? Activator.CreateInstance(type) : null))
				continue;
			if (param.Value is string && String.IsNullOrEmpty((string)param.Value))
				continue;
			comm.Parameters.Add(driver.CreateParameter(param.Name, param.Value));
		}
		return comm;
	}
}