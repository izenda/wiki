﻿using System;
using System.Collections.Generic;
using Izenda.AdHoc;
using Izenda.AdHoc.Database;
using Izenda;
using Izenda.Fusion;
using System.Linq;

	[Serializable]
public class SomeDataExtractor : SqlDataExtractor
{
	public override List<ExtractedTable> GetSchema()
	{
		List<Table> datasources = new List<Table>();
		datasources.AddRange(underlyingDriver.GetAllTables());
		foreach (Table table in datasources)
		{
			Column[] columns = underlyingDriver.GetColumns(table);
			foreach (Column column in columns)
				if (column != null)
					table.Columns.Add(column.Name, column);
		}
		List<ExtractedTable> schema = new List<ExtractedTable>(datasources.Select<Table, ExtractedTable>(ds => new ExtractedTable(ds)));
		return schema;
	}

	public SomeDataExtractor(string connectionString, SomeFusionDriver drv)
		: base(connectionString)
	{
		underlyingDriver = drv;
	}
}
