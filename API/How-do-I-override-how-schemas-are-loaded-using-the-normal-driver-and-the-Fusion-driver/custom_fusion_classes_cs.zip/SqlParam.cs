﻿public class SqlParam : Pair<string, object>
{
	public SqlParam(string key, object value)
		: this(key, value, false)
	{
	}
	public SqlParam(string key, object value, bool ignoreEmpty)
		: base(key, value)
	{
		IgnoreEmpty = ignoreEmpty;
	}

	public string Name
	{
		get { return First; }
		set { First = value; }
	}
	public object Value
	{
		get { return Second; }
		set { Second = value; }
	}
	public bool IgnoreEmpty
	{
		get;
		set;
	}
}