﻿using System;
using System.Data;
using Izenda;
using Izenda.Fusion;
using Izenda.AdHoc;
using Izenda.AdHoc.Database;

[Serializable]
public class SomeFusionDriver : SomeDriver, IDirectFusionDriver
{
	public string myAlias;
	public string aliasSeparator;

	public string StripAlias(string s, string aliasToStrip)
	{
		if (String.IsNullOrEmpty(aliasToStrip))
			return s;
		string result = s;
		string aliasNodeLow = (aliasToStrip + aliasSeparator).ToLower();
		int cutLength = aliasNodeLow.Length;
		int pos = result.ToLower().IndexOf(aliasNodeLow);
		while (pos >= 0)
		{
			if (pos == 0 || !Char.IsLetterOrDigit(result[pos - 1]))
				result = result.Substring(0, pos) + result.Substring(pos + cutLength);
			else
				result = result.Substring(0, pos) + "##&BADALIAS&##" + result.Substring(pos + cutLength);
			pos = result.ToLower().IndexOf(aliasNodeLow);
		}
		result = result.Replace("##&BADALIAS&##", aliasToStrip + aliasSeparator);
		return result;
	}

	public string StripAliases(string s)
	{
		string[] otherAliases = MainFusionDriverAllAliases;
		string result = s;
		bool myAliasFound = false;
		if (otherAliases != null)
		{
			foreach (string mfdAlias in otherAliases)
			{
				if (mfdAlias == myAlias)
					myAliasFound = true;
				result = StripAlias(result, mfdAlias);
			}
		}
		if (!myAliasFound)
			result = StripAlias(result, myAlias);
		return result;
	}

	public override DataSet GetDataSet(IDbCommand command, string reportPart)
	{
		command.CommandText = StripAliases(command.CommandText);
		return base.GetDataSet(command, reportPart);
	}

	public override DataTable GetDataTable(Report report, IDbCommand command)
	{
		command.CommandText = StripAliases(command.CommandText);
		return base.GetDataTable(report, command);
	}

	public override IDataReader GetDataReader(IDbCommand command)
	{
		command.CommandText = StripAliases(command.CommandText);
		return base.GetDataReader(command);
	}

	public SomeFusionDriver(string fAlias, string fAliasSeparator, string cs)	: base(cs)
	{
		myAlias = fAlias;
		aliasSeparator = fAliasSeparator;
		if (AdHocContext.DriverExists)
			Parent = AdHocContext.Driver;
	}

	public SomeFusionDriver()
	{
	}
}
