﻿using System;
using System.Collections;
using System.Data;
using Izenda;
using Izenda.Fusion;
using Izenda.AdHoc;
using Izenda.AdHoc.Database;

[Serializable]
public class SomeDriver : MSSQLDriver
{
	public override Table[] GetAllTables()
	{
		//here pulling list of tables can be customized
		string database = GetDatabase();
		if (!String.IsNullOrEmpty(database))
			database += "].[";
		else
			database = "";
		string[] dirtyAllVds = AdHocSettings.VisibleDataSources;
		string[] cleanNewVds = VisibleDatasourcesNoAliases(dirtyAllVds, false);
		string dataSources = "";
		for (int i = 0; i < cleanNewVds.Length; i++)
		{
			if (!String.IsNullOrEmpty(dataSources))
				dataSources += ",";
			dataSources += String.Format("'{0}'", cleanNewVds[i].Replace("'", "''").ToUpper());
		}
		string schemaCondition = "";
		if (UseTablesFromSchemaOnly)
			schemaCondition = String.Format("AND TABLE_SCHEMA = '{0}'", DefaultSchemaName);
		string dsSnippet = "IS NOT NULL";
		if (!String.IsNullOrEmpty(dataSources))
			dsSnippet = String.Format("IN ({0})", dataSources);
		IDbCommand tablesCommand = SqlToolkit.CreateCommand(this, String.Format(GetTablesAndViewsSQL, dsSnippet, schemaCondition));
		DataSet dataSet = GetDataSetCached(tablesCommand);
		ArrayList result = new ArrayList();
		foreach (DataRow row in dataSet.Tables[0].Rows)
		{
			Table table = new Table(row["TABLE_NAME"].ToString(), database + row["TABLE_SCHEMA"].ToString());
			if (row["TABLE_TYPE"].ToString() == "VIEW")
				table.Type = TableType.View;
			result.Add(table);
		}
		return (Table[]) result.ToArray(typeof(Table));
	}

	public override StoredProcedure[] GetAllStoredProcedures()
	{
		return new StoredProcedure[0];
	}

	public override StoredProcedure[] FullStoredProceduresList()
	{
		return new StoredProcedure[0];
	}

	public override Column[] GetColumns(Table table)
	{
		//here pulling list of columns can be customized
		SqlParam[] parameters = new SqlParam[1];
		parameters[0] = new SqlParam("tableName", table.FullName);
		IDbCommand command = SqlToolkit.CreateCommand(this, String.Format(GetColumnsSQL, "=UPPER(@tableName)", ""), parameters);
		DataSet dataSet = GetDataSetCached(command);
		ArrayList result = new ArrayList();
		foreach (DataRow row in dataSet.Tables[0].Rows)
		{
			string dbType = row["DATA_TYPE"].ToString();
			SqlType type = GetSqlTypeByDbType(dbType);
			Column column = new Column(row["COLUMN_NAME"].ToString().Replace(".", "_INTERNALDOTCHAR_"), type, dbType);
			result.Add(column);
		}
		return (Column[]) result.ToArray(typeof(Column));
	}

	public SomeDriver() : this(null)
	{
	}

	public SomeDriver(string connectionString) : base(connectionString)
	{
	}
}
