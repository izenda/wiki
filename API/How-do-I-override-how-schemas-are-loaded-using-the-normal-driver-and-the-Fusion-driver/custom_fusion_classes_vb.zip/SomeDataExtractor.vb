﻿Imports Microsoft.VisualBasic
Imports Izenda
Imports Izenda.Fusion
Imports Izenda.AdHoc
Imports Izenda.AdHoc.Database

Public Class SomeDataExtractor
	Inherits SqlDataExtractor

	Public Overrides Function GetSchema() As List(Of ExtractedTable)
		Dim datasources As List(Of Table) = New List(Of Table)
		datasources.AddRange(underlyingDriver.GetAllTables())
		For Each table As Table In datasources
			Dim columns As Column() = underlyingDriver.GetColumns(table)
			For Each column As Column In columns
				If Not (column Is Nothing) Then
					table.Columns.Add(column.Name, column)
				End If
			Next
		Next
		Dim schema As List(Of ExtractedTable) = New List(Of ExtractedTable)(datasources.Select(Function(ds) New ExtractedTable(ds)))
		Return schema
	End Function

	Public Sub New(connectionString As String, drv As SomeFusionDriver)
		MyBase.New(connectionString)
		underlyingDriver = drv
	End Sub
End Class
