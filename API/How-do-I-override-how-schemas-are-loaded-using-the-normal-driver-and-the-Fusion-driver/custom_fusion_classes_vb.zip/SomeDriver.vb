﻿Imports Microsoft.VisualBasic
Imports Izenda
Imports Izenda.AdHoc
Imports Izenda.AdHoc.Database
Imports System.Data

<Serializable()>
Public Class SomeDriver
	Inherits MSSQLDriver
	Public Overrides Function GetAllTables() As Table()
		'here pulling list of tables can be customized
		Dim database As String = GetDatabase()
		If Not (String.IsNullOrEmpty(database)) Then
			database = database & "].["
		Else
			database = ""
		End If
		Dim dirtyAllVds As String() = AdHocSettings.VisibleDataSources
		Dim cleanNewVds As String() = VisibleDatasourcesNoAliases(dirtyAllVds, False)
		Dim dataSources As String = ""
		For i As Integer = 0 To cleanNewVds.Length - 1
			If Not (String.IsNullOrEmpty(dataSources)) Then
				dataSources = dataSources & ","
			End If
			dataSources = dataSources & String.Format("'{0}'", cleanNewVds(i).Replace("'", "''").ToUpper())
		Next
		Dim schemaCondition As String = ""
		If UseTablesFromSchemaOnly Then
			schemaCondition = String.Format("AND TABLE_SCHEMA = '{0}'", DefaultSchemaName)
		End If
		Dim dsSnippet As String = "IS NOT NULL"
		If Not (String.IsNullOrEmpty(dataSources)) Then
			dsSnippet = String.Format("IN ({0})", dataSources)
		End If
		Dim tablesCommand As IDbCommand = SqlToolkit.CreateCommand(Me, String.Format(GetTablesAndViewsSQL, dsSnippet, schemaCondition))
		Dim dataSet As DataSet = GetDataSetCached(tablesCommand)
		Dim result As ArrayList = New ArrayList()
		For Each row As DataRow In dataSet.Tables(0).Rows
			Dim table As Table = New Table(row("TABLE_NAME").ToString(), database & row("TABLE_SCHEMA").ToString())
			If row("TABLE_TYPE").ToString() = "VIEW" Then
				table.Type = TableType.View
			End If
			result.Add(table)
		Next
		Return DirectCast(result.ToArray(GetType(Table)), Table())
	End Function

	Public Overrides Function GetAllStoredProcedures() As StoredProcedure()
		Dim result(-1) As StoredProcedure
		Return result
	End Function

	Public Overrides Function FullStoredProceduresList() As StoredProcedure()
		Dim result(-1) As StoredProcedure
		Return result
	End Function

	Public Overrides Function GetColumns(table As Table) As Column()
		'here pulling list of columns can be customized
		Dim parameters(0) As SqlParam
		parameters(0) = New SqlParam("tableName", table.FullName)
		Dim command As IDbCommand = SqlToolkit.CreateCommand(Me, String.Format(GetColumnsSQL, "=UPPER(@tableName)", ""), parameters)
		Dim dataSet As DataSet = GetDataSetCached(command)
		Dim result As ArrayList = New ArrayList()
		For Each row As DataRow In dataSet.Tables(0).Rows
			Dim dbType As String = row("DATA_TYPE").ToString()
			Dim type As SqlType = GetSqlTypeByDbType(dbType)
			Dim column As Column = New Column(row("COLUMN_NAME").ToString().Replace(".", "_INTERNALDOTCHAR_"), type, dbType)
			result.Add(column)
		Next
		Return DirectCast(result.ToArray(GetType(Column)), Column())
	End Function

	Public Sub New()
		Me.New(Nothing)
	End Sub

	Public Sub New(connectionString As String)
		MyBase.New(connectionString)
	End Sub

End Class


