﻿Imports Microsoft.VisualBasic
Imports Izenda
Imports Izenda.Fusion
Imports Izenda.AdHoc
Imports Izenda.AdHoc.Database

<Serializable()>
Public Class SomeFusionDriver
	Inherits SomeDriver
	Implements IDirectFusionDriver

	Public myAlias As String
	Public aliasSeparator As String

	Public Function StripAlias(s As String, aliasToStrip As String) As String
		If String.IsNullOrEmpty(aliasToStrip) Then
			Return s
		End If
		Dim result As String = s
		Dim aliasNodeLow As String = (aliasToStrip & aliasSeparator).ToLower()
		Dim cutLength As Integer = aliasNodeLow.Length
		Dim pos As Integer = result.ToLower().IndexOf(aliasNodeLow)
		While pos >= 0
			If (pos = 0) OrElse (Not (Char.IsLetterOrDigit(result(pos - 1)))) Then
				result = result.Substring(0, pos) & result.Substring(pos + cutLength)
			Else
				result = result.Substring(0, pos) & "##&BADALIAS&##" & result.Substring(pos + cutLength)
			End If
			pos = result.ToLower().IndexOf(aliasNodeLow)
		End While
		result = result.Replace("##&BADALIAS&##", aliasToStrip & aliasSeparator)
		Return result
	End Function

	Public Function StripAliases(s As String) As String Implements IDirectFusionDriver.StripAliases
		Dim otherAliases As String() = MainFusionDriverAllAliases
		Dim result As String = s
		Dim myAliasFound As Boolean = False
		If Not (otherAliases Is Nothing) Then
			For Each mfdAlias As String In otherAliases
				If mfdAlias = myAlias Then
					myAliasFound = True
				End If
				result = StripAlias(result, mfdAlias)
			Next
		End If
		If myAliasFound = False Then
			result = StripAlias(result, myAlias)
		End If
		Return result
	End Function

	Public Overrides Function GetDataSet(command As Data.IDbCommand, reportPart As String) As Data.DataSet
		command.CommandText = StripAliases(command.CommandText)
		Return MyBase.GetDataSet(command, reportPart)
	End Function

	Public Overrides Function GetDataTable(report As Report, command As Data.IDbCommand) As Data.DataTable
		command.CommandText = StripAliases(command.CommandText)
		Return MyBase.GetDataTable(report, command)
	End Function

	Public Overrides Function GetDataReader(command As Data.IDbCommand) As Data.IDataReader
		command.CommandText = StripAliases(command.CommandText)
		Return MyBase.GetDataReader(command)
	End Function

	Public Sub New(fAlias As String, fAliasSeparator As String, cs As String)
		MyBase.New(cs)
		myAlias = fAlias
		aliasSeparator = fAliasSeparator
		If AdHocContext.DriverExists Then
			Parent = AdHocContext.Driver
		End If
	End Sub


	Public Sub New()
	End Sub

End Class
