﻿Imports Microsoft.VisualBasic

Public Class SqlParam
	Inherits Pair(Of String, Object)
	Public IgnoreEmpty As Boolean

	Public Property Name() As String
		Get
			Return First
		End Get
		Set(ByVal value As String)
			First = value
		End Set
	End Property

	Public Property Value() As Object
		Get
			Return Second
		End Get
		Set(ByVal value As Object)
			Second = value
		End Set
	End Property

	Public Sub New(key As String, value As Object)
		Me.New(key, value, False)
	End Sub

	Public Sub New(key As String, value As Object, ie As Boolean)
		MyBase.New(key, value)
		IgnoreEmpty = ie
	End Sub
End Class
