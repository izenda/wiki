﻿Imports Microsoft.VisualBasic

Public Class Pair(Of T1, T2)
	Public First As T1
	Public Second As T2

	Public Sub New(t1 As T1, t2 As T2)
		First = t1
		Second = t2
	End Sub
End Class
