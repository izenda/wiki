﻿Imports Microsoft.VisualBasic
Imports System.Data
Imports Izenda
Imports Izenda.AdHoc
Imports Izenda.AdHoc.Database

Public Class SqlToolkit
	Public Shared Function CreateCommand(driver As Driver, command As String) As IDbCommand
		Return CreateCommand(driver, Nothing, command, Nothing, Nothing)
	End Function

	Shared Function CreateCommand(driver As Driver, command As String, parameters As SqlParam()) As IDbCommand
		Return CreateCommand(driver, Nothing, command, Nothing, parameters)
	End Function

	Public Shared Function CreateCommand(driver As Driver, connection As IDbConnection, command As String, commandType As CommandType?, parameters As SqlParam()) As IDbCommand
		Dim comm As IDbCommand = driver.CreateCommand(command)
		comm.CommandTimeout = driver.CmdTimeout
		If Not (connection Is Nothing) Then
			comm.Connection = connection
		End If
		If Not (commandType Is Nothing) Then
			comm.CommandType = commandType.Value
		End If
		If parameters Is Nothing Then
			Return comm
		End If
		For Each param As SqlParam In parameters
			If Not (param.IgnoreEmpty) Then
				comm.Parameters.Add(driver.CreateParameter(param.Name, param.Value))
				Continue For
			End If
			If param.Value Is Nothing Then
				Continue For
			End If
			Dim type As Type = param.Value.GetType()
			Dim nv As Object
			If type.IsValueType Then
				nv = Activator.CreateInstance(type)
			Else
				nv = Nothing
			End If
			If Equals(param.Value, nv) Then
				Continue For
			End If
			If (TypeOf (param.Value) Is String) AndAlso (String.IsNullOrEmpty(param.Value)) Then
				Continue For
			End If
			comm.Parameters.Add(driver.CreateParameter(param.Name, param.Value))
		Next
		Return comm
	End Function
End Class